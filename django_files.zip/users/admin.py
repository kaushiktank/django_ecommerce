from django.contrib import admin
from .models import Address, UserMobileNo

admin.site.register(Address)
admin.site.register(UserMobileNo)
