EMAIL_HOST = "smtp.gmail.com"
EMAIL_HOST_USER = "pragnakalpdjango@gmail.com"
EMAIL_HOST_PASSWORD = "bsxtljaxernwvdxg"
EMAIL_PORT = 587
EMAIL_USE_TLS = True
DEFAULT_FORM_EMAIL = "pragnakalpdjango@gmail.com"